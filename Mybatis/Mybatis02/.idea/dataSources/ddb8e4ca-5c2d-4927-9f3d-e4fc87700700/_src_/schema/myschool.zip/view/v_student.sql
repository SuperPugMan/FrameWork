CREATE VIEW v_student AS
  SELECT
    `myschool`.`student`.`studentName` AS `学生姓名`,
    `myschool`.`student`.`address`     AS `学生地址`,
    `myschool`.`grade`.`gradeName`     AS `学生年级`
  FROM `myschool`.`student`
    JOIN `myschool`.`grade`
  WHERE (`myschool`.`student`.`gradeId` = `myschool`.`grade`.`gradeId`);
