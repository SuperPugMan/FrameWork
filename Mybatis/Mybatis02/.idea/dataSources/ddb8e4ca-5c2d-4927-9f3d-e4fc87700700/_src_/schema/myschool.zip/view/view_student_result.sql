CREATE VIEW view_student_result AS
  SELECT
    `myschool`.`student`.`studentName`  AS `姓名`,
    `myschool`.`student`.`studentNo`    AS `学号`,
    `myschool`.`result`.`studentResult` AS `成绩`,
    `myschool`.`subject`.`subjectName`  AS `课程名称`,
    `myschool`.`result`.`examDate`      AS `考试日期`
  FROM ((`myschool`.`student`
    JOIN `myschool`.`result` ON ((`myschool`.`student`.`studentNo` = `myschool`.`result`.`studentNo`))) JOIN
    `myschool`.`subject` ON ((`myschool`.`result`.`subjectNo` = `myschool`.`subject`.`subjectNo`)))
  WHERE ((`myschool`.`subject`.`subjectNo` = (SELECT `myschool`.`subject`.`subjectNo`
                                              FROM `myschool`.`subject`
                                              WHERE (`myschool`.`subject`.`subjectName` = 'Login Java'))) AND
         (`myschool`.`result`.`examDate` = (SELECT max(`myschool`.`result`.`examDate`)
                                            FROM `myschool`.`result`
                                              JOIN `myschool`.`subject`
                                            WHERE
                                              ((`myschool`.`result`.`subjectNo` = `myschool`.`subject`.`subjectNo`) AND
                                               (`myschool`.`subject`.`subjectName` = 'Login Java')))));
